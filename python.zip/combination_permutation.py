import itertools # provides functions for creating iterators for efficient looping
# itertools is designed for creating and working with iterators,Iterators allow you to traverse through data without the
# need to store the entire dataset in memory, making it efficient for large datasets
def generate_combinations(elements, length): # function to generate combinations of a specified length from the given elements
    return list(itertools.combinations(elements, length)) # to create and return a list of combinations.

def generate_permutations(elements, length):
    return list(itertools.permutations(elements, length))

# Example usage
elements = [1, 2, 3]
combinations = generate_combinations(elements, 2) # selections of items where the order does not matter
permutations = generate_permutations(elements, 2) # generate all possible ordered arrangements of a subset of elements(order matters)

print("Combinations:", combinations)
print("Permutations:", permutations)

#  #for counting
# counter = itertools.count()    # Create an infinite counter starting from 0
# first_ten_numbers = list(itertools.islice(counter, 10))  # Get the first 10 numbers from the counter
# print("First 10 numbers:", first_ten_numbers)

#for combining :
iterate1= [12]
iterate2= [3]
combined=list(itertools.chain(iterate1,iterate2))
print(combined)