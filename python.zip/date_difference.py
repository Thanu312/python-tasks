from datetime import datetime  # for date manipulation

def date_difference(date1, date2):
    format = "%Y-%m-%d"  # Format for the input dates
    d1 = datetime.strptime(date1, format)  # This is a method from the datetime class that parses a string representing
    # a date and time and converts it into a datetime object.
    d2 = datetime.strptime(date2, format)  # September 18, 2024   ( "string parameter time")
    difference = abs((d2 - d1).days) # The abs function returns the absolute value of a number
    # .days attribute is used to extract just the number of days from a timedelta object, which represents a duration between two dates
    return difference

# Example usage
date1 = "2003-12-03"
date2 = "2024-09-18"
print(f"Difference in days: {date_difference(date1, date2)}")
