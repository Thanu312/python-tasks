from datetime import datetime  # for date manipulation

def date_difference(date1, date2):
    format = "%Y-%m-%d"  # Format for the input dates
    d1 = datetime.strptime(date1, format)  # Convert string to datetime object
    d2 = datetime.strptime(date2, format)  # Convert string to datetime object

    # Initialize the difference variables
    years = d2.year - d1.year   #.year is an attribute of a datetime object and it retrieves the year portion of that date.
    months = d2.month - d1.month
    days = d2.day - d1.day
    return abs(years), abs(months), abs(days)

# Example usage
date1 = "2004-12-03"
date2 = "2024-09-18"
years, months, days = date_difference(date1, date2)
print(f"Difference: {years} years, {months} months, and {days} days")
